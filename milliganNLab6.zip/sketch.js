let Paddle1X = 50;
let Paddle1Y = 250;
let Paddle2X = 730;
let Paddle2Y = 250;
let ballX = [400];
let ballY = [250];
let moveBallX = [-5];
let moveBallY = [5];
let closestBall = 0;

function setup() {
  createCanvas(800, 500);
  print(ballX.length);
  for(let i = 0; i < 3; i++){
    ballX[ballX.length] = 400;
  ballY[ballY.length] = 250;
  moveBallX[ballX.length] = random(-10, 11);
  moveBallY[ballY.length] = random(-10, 11);
  }
}

function draw() {
  background(25);
  drawPaddles();
  for(let i = 0; i < ballX.length; i++){
    fill('white');
    circle(ballX[i],ballY[i],20);
    ballX[i]+=moveBallX[i];
    ballY[i]+=moveBallY[i];
    if(ballX[i] < 70 && (ballY[i] > Paddle1Y && ballY[i] < Paddle1Y + 100)){
      ballX[i]-=moveBallX[i];
      moveBallX[i] *= -1;
    }
    if(ballX[i] > 730 && (ballY[i] > Paddle2Y && ballY[i] < Paddle2Y + 100)){
      ballX[i]-=moveBallX[i];
      moveBallX[i] *= -1;
    }
    if(ballY[i] < 0 || ballY[i] > 500){
      ballY[i]-=moveBallY[i];
      moveBallY[i] *= -1;
    }
    
    if(ballX[i] > 750 || ballX[i] < 50){
      ballX[i] = 9999;
    }
  }
}
function mousePressed(){
  ballX[ballX.length] = 400;
  ballY[ballY.length] = 250;
  moveBallX[ballX.length] = random(-10, 11);
  moveBallY[ballY.length] = random(-10, 11);
      console.log(ballY.length);
}


function drawPaddles(){
  fill('red');
  rect(Paddle1X,Paddle1Y,20,100);
  fill('blue');
  rect(Paddle2X,Paddle2Y,20,100);
  
  
  closestBall = 0;
  for(let i = 0; i < ballY.length; i++){
    if(dist(Paddle1X+10,Paddle1Y+50,ballX[i],ballY[i]) < dist(Paddle1X+10,Paddle1Y+50,ballX[closestBall],ballY[closestBall])){
        closestBall = i;
       }
  }
  if((ballY[closestBall]-Paddle1Y-50) > 0){
    Paddle1Y += 20;
  } else {
    Paddle1Y -= 20;
  }
  
   closestBall = 0;
    for(let i = 0; i < ballY.length; i++){
    if(dist(Paddle2X-10,Paddle2Y+50,ballX[i],ballY[i]) < dist(Paddle2X-10,Paddle2Y+50,ballX[closestBall],ballY[closestBall])){
        closestBall = i;
       }
  }
  if((ballY[closestBall]-Paddle2Y-50) > 0){
    Paddle2Y += 20;
  } else {
    Paddle2Y -= 20;
  }
  
  if(Paddle1Y < 0){
    Paddle1Y = 0;
  }
   if(Paddle2Y < 0){
    Paddle2Y = 0;
  }
     if(Paddle2Y > 400){
    Paddle2Y = 400;
  }
  
  if(Paddle1Y > 400){
    Paddle1Y = 400;
  }
}