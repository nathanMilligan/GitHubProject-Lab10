let snowflakeX = [];
let snowflakeY = [];
let snowflakeRotation = [];
let snowflakeArms = [];
let snowflakeSize = [];
let snowflakeFall = [];
let snowflakeThick = [];
function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
    for(let i = 0; i < 50; i++){
    snowflakeX[i] = int(random(0,width));
    snowflakeY[i] = int(random(0,height));
    snowflakeRotation[i] = int(random(0,360));
    snowflakeArms[i] = int(random(3,12));
    snowflakeSize[i] = int(random(5,9));
    snowflakeFall[i] = (random(-1,-1.5));
    snowflakeThick[i] = int(random(2,7));
  }
}
function mouseClicked() {
  snowflakeX[amountOfSnow()] = mouseX;
    snowflakeY[amountOfSnow()] = mouseY;
    snowflakeRotation[amountOfSnow()] = int(random(0,360));
    snowflakeArms[amountOfSnow()] = int(random(3,12));
    snowflakeSize[amountOfSnow()] = int(random(5,9));
    snowflakeFall[amountOfSnow()] = (random(-1,-1.5));
    snowflakeThick[amountOfSnow()] = int(random(2,7));
}
function amountOfSnow(){
  print(`snowflakes on screen: ${snowflakeX.length}`);
  return snowflakeX.length;
}
function draw() {
  background(150);
  
  
  for(let i = 0; i < snowflakeX.length; i++){
    drawSnowflake(snowflakeX[i],snowflakeY[i],snowflakeRotation[i],snowflakeArms[i],snowflakeSize[i],snowflakeThick[i]);
    snowflakeRotation[i]++;
    snowflakeY[i] -= snowflakeFall[i];
      if(snowflakeY[i] > height+40){
    snowflakeY[i] = -40;
  }
    if(snowflakeX[i] > width+40){
    snowflakeX[i] = -40;
  }
    snowflakeX[i] += 1-(snowflakeSize[i]*0.1);
  }
  drawSnowflake(100,110);
}

function drawSnowflake(x,y,rotation,arms,size,thick){
  push();
  translate(x, y);
  scale(size / 8);
  rotate(rotation);
  stroke('white');
  strokeWeight(thick);
  
  for(let i = 0; i < arms; i++){
    line(0,0,0,-size);
    rotate(360/arms);
  }
  pop();
}