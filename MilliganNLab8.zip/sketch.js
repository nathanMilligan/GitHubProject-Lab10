//https://www.creativefabrica.com
let transparentImage;

// https://www.vecteezy.com/png/29228888-apple-png-transparent-background
let appleImage;

// https://www.vecteezy.com/png/40532916-ai-generated-empty-wooden-basket-on-transparent-background-ai-generated
let basketImage;

let points = 0;
let apples = 0;
let timer = 0;
let appleX = [];
let appleY = [];

function preload() {
  appleImage = loadImage("apple.png");
  basketImage = loadImage("basket.png");
  transparentImage = loadImage("transparent.png");
}

function setup() {
  createCanvas(480, 420);
  appleX[apples] = random(35,width-35);
    appleY[apples] = 0;
    apples = 1;
}

function draw() {
  timer++;
    background(255);
  if(timer > 50){
    appleX[apples] = random(35,width-35);
    appleY[apples] = 0;
    apples++;
    timer = 0;
  }
  for(let i = 0; i < apples; i++){
    image(appleImage, appleX[i], appleY[i], 70, 50);
    appleY[i] += 3;
    if(appleY[i] > height-70 && appleY[i] < 1000){
      if(dist(appleX[i], appleY[i], mouseX, height-60) <= 70){
        points++;
      } else{
        points = 0;
      }
      appleY[i] = 1001;
    }
  }

   textFont("Ariel");
  textSize(24);
  fill(0);
  text("Score: " + points, 10, 30);
     image(transparentImage, mouseX-35, mouseY-500, 70, 1000);
  image(basketImage, mouseX-35, height-60, 70, 50);

}
